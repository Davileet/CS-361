/*-------------------------------------------------------------
CS-361 Fall 2015
Phase 3: IPC using shared memory.
Written by:
	David Thompson
-------------------------------------------------------------*/
#ifndef	manufacturing_c
#define	manufacturing_c

#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>
#include <errno.h>
#include <time.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>

#include <string.h>
#include <sys/wait.h>
#include <unistd.h>

#include "manufacturing.h"
#include "hardware.h"
#include "statemodel.h"

#define MYPORT "5560"
#define MAXBUFLEN 256

//Takes care of the possible button presses.
state_t manufacturing = {
		default_event_handler,	//order receieved
		default_event_handler,	//payment validated
		default_event_handler,	//payment rejected
		factory_failed,		//factory failed
		factory_success,		//factory success
		default_event_handler,	//shipment confirmed
		default_event_handler,	//shipment failed
		entry_to,			//entry
		exit_from			//exit
};

//If the factory failed button is pressed.
state_t* factory_failed()
{
	exit_from();
	printf("Updating stats with FAIL\n");
	return &accepting;
}

//If the factory success button is pressed.
state_t* factory_success()
{
	exit_from();
	printf("Manufacturing successful.\n");
	chargeClient();
	return &shipping;
}

//Method that holds output for when client is charged.
void chargeClient()
{
	printf("Charging Client.\n");
}

// get sockaddr, IPv4 or IPv6:
void *get_in_addr(struct sockaddr *sa)
{
	//ARPA internet protocols. AF_INET socks are associated with an IP port number.
    if (sa->sa_family == AF_INET) {
        return &(((struct sockaddr_in*)sa)->sin_addr);
    }

    return &(((struct sockaddr_in6*)sa)->sin6_addr);
}

//Main method when manufacturing is entered.
void entry_to()
{
   	struct MessageStruct
	{
	int msgFlag;
	int lineID;
	int lineCap;
	int lineDur;
	int lineItr;
	int totalDur;
	int lineTotal;
	int lineCount;
	int order;
	};

	struct MessageStruct a;
	struct addrinfo hints, *servinfo, *p;
	struct sockaddr_storage their_addr;
    int sockfd = 0;
    int rv;
    long numbytes;
    int totalDuration;
    
    char buf[MAXBUFLEN];
    socklen_t addr_len;
    char s[INET6_ADDRSTRLEN];
    
    int getInfo, makeParts;
    int order_size;
    int counter = 1;

    /* Randomly generate an order size */
	srandom(time(0));
	order_size = random() % 40000 + 10001;
	a.order = order_size;
	printf("\nOrder size randomly generated: %d\n", a.order);

    
    memset(&hints, 0, sizeof hints);
    hints.ai_family = AF_UNSPEC; // set to AF_INET to force IPv4 or INET
    hints.ai_socktype = SOCK_DGRAM; //set type to datagram.
    hints.ai_flags = AI_PASSIVE; // use my IP
    
    //hints.ai_addr = htonl(INADDR_ANY);
    //hints.ai_addr.s_addr = htonl( INADDR_ANY );

    if ((rv = getaddrinfo(NULL, MYPORT, &hints, &servinfo)) != 0) {
        fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(rv));
        exit(1);
    	}

    // loop through all the results and bind to the first we can
    for(p = servinfo; p != NULL; p = p->ai_next) {
        printf("\nin loop\n");
        //creates a socket and returns descriptor to sockfd. One end point of communication.
        //address family, communication type, protocol employed.
        if ((sockfd = socket(p->ai_family, p->ai_socktype,
                p->ai_protocol)) == -1) {
            perror("UDPserver: socket");
            continue;
        }

	//bind assigns the address specified, addr, to the socket. 
        if (bind(sockfd, p->ai_addr, p->ai_addrlen) == -1) {
            close(sockfd);
            perror("UDPserver: bind");
            continue;
        }
        break;
    	}
    		if (p == NULL) {
       			fprintf(stderr, "UDPserver: failed to bind socket\n");
       			exit(2);
    		}

    freeaddrinfo(servinfo);
    printf("UDPserver: waiting to recvfrom...\n\n");  

    addr_len = sizeof their_addr;
    
    while (1) {
    
    	printf("Server is recieving from client...\n");
    	numbytes = recvfrom(sockfd, buf, MAXBUFLEN-1 , 0,
        	(struct sockaddr *)&their_addr, &addr_len);

    		if (numbytes < 0){
    			perror("Error in recvfrom");
    			exit(1);
    			}
    	
    	printf("UDPserver: got packet from %s ",
        	inet_ntop(their_addr.ss_family,
          	  get_in_addr((struct sockaddr *)&their_addr),
          	  s, sizeof s));
   	 	buf[numbytes] = '\0';
   		printf(" UDPserver: packet contains \"%s\"\n", buf);
   		
 
//Compare message recieved and prepare a corresponding message to send.   
    getInfo = strcmp(buf, "0");	
   	makeParts = strcmp(buf, "1");
   	
	//msg is zero.
    if (getInfo == 0) { 
    		a.lineID = counter++;
			a.lineDur = random() % 400000 + 400001;
			a.lineCap = random() % 500 + 501;
			a.totalDur = 0;
			a.lineItr = 0;
			a.lineTotal = 0;
			a.lineCount = counter;
			a.msgFlag = 1;

    	printf("Sending response. Line Number %d, Duration %dms, Capacity %d Itr %d\n", 
    		a.lineID, a.lineDur, a.lineCap, a.lineItr);
    	
    		if (sendto(sockfd, &a, sizeof(a), 0, 
				(struct sockaddr *)&their_addr, addr_len) < 0) {
				perror("sendto");
			}
    	} // if getInfo

	//msg is one.
    else if (makeParts == 0) {
		if (a.order == 0) {
			//for (i = 0; i < counter; i++) {
				printf("\nRecieved a request but nothing remains.\n");
				totalDuration = a.totalDur / 1000000;
				
				printf("LineID %d, Total items made %d, Total line duration %d seconds.\n\n",
    				a.lineID, a.lineTotal, totalDuration);
    			printf("You have 20 seconds to start manufacturing again before factory lines shut down.\n");
    			
    		a.lineCount--;
			printf(">");
			
			if (a.lineCount == 0) {
			close(sockfd);
			break;
			}
		} //if
		
		else if (a.order < a.lineCap)
    	{	
    		printf("\nCurrent order size %d Line capacity %d\n", a.order, a.lineCap);
			a.lineCap = a.lineCap - (a.lineCap - a.order);
			
			a.order = 0;
			a.msgFlag = 0;
			
    		printf("Order size is less than line capacity, sending remaining parts %d.\n\n", a.lineCap);
			
			if (sendto(sockfd, &a, sizeof(a), 0, 
				(struct sockaddr *)&their_addr, addr_len) < 0) {
				perror("sendto");
					}
			}// else if 
				
    	else {  	
    			printf("\nCurrent order size: %d\n", a.order);
    			printf("Incoming line capacity: %d\n", a.lineCap);
    		
    			a.order = a.order - a.lineCap;
    			
    			a.lineTotal += a.lineCap;
    			a.lineItr++;
    			a.totalDur += a.lineDur;
    			a.msgFlag = 1;
    			usleep(a.lineDur);
    			printf("Sending success of %d parts created.\n\n", a.lineCap);
    			if (sendto(sockfd, &a, sizeof(a), 0, 
					(struct sockaddr *)&their_addr, addr_len) < 0) {
					perror("sendto");
					}
    		}//else 
    	}//else if makeparts 

    else {
    	printf("Oops...\n");
    	perror("incorrect message");
   		}//else 
	}//while     
}//entry_to 

//Leaving manufacturing and shut down lines.
void exit_from()
{
	factory_line(LINE_OFF);
}

#endif
