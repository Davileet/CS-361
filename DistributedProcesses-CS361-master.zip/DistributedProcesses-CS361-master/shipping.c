#ifndef shipping_c
#define shipping_c

#include <stdio.h>
#include "shipping.h"
#include "hardware.h"
#include "statemodel.h" //For the other states.

//Create the object of the opening state.
state_t shipping = {
			//order received
	default_event_handler,	//order received
	default_event_handler,	//payment validated
	default_event_handler,	//payment rejected
	default_event_handler,	//factory failed
	default_event_handler,	//factory success
	shipment_confirmed,		//shipment confirmed
	shipment_failed,         //shipment failed
	entry_to,				//entry
	default_action			//exit
};

state_t* shipment_failed()
{
    printf("Shipment has failed. Oops.\n");
	return &accepting;
}

state_t* shipment_confirmed()
{
    printf("Starting warranty.\n");
	return &accepting;
}

void entry_to()
{
    printf("Current State: Shipping\n");
	getAddress();
}

#endif

