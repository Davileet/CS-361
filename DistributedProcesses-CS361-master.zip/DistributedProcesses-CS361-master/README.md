# DistributedProcesses

Program that creates a finite machine and processes application in a distributed fashion.
