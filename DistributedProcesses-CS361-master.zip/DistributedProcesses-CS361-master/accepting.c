#ifndef accepting_c
#define accepting_c

#include <stdio.h>
#include "accepting.h"
#include "hardware.h"
#include "statemodel.h" //For the other states

//Create the object of the accepting state.
state_t accepting = {
	order_received,			//order recieved
	default_event_handler,		//payment validated
	default_event_handler,		//payment rejected
	default_event_handler,		//factory failed
	default_event_handler,		//factory success
	default_event_handler,		//shipment confirmed
	default_event_handler,		//shipment failed.
	entry_to,			//entry
	exit_from			//exit
};

state_t* order_received()
{
	exit_from();
	return &processing;
}

void entry_to()
{
	set_order_progress(ORDER_PROCESSING);
}

void exit_from()
{
    	printf("Resetting attempts.\n");
	set_order_progress(ORDER_FINALIZING);
}

#endif
