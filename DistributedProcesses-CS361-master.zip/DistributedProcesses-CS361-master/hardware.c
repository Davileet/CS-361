#ifndef hardware_c
#define hardware_c

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "hardware.h"

void factory_line(line_setting ls)
{
	switch(ls){
		case 0:
			printf("Dispatching factory lines.\n\n");
			break;
		case 1:
			printf("Shutting down factory lines.\n");
			break;
        case 2:
            break;
	}
}

void get_payment_method(card c)
{
	switch (c)
	{
		case 0:
			printf("Getting payment method.\n>");
			break;
	}
}

void set_order_progress(order_setting os)
{
	switch (os) {
		case 0:
			printf("Current State: Accepting.\n>");
			break;
		case 1:
			printf("Leaving Order.\n");
			break;
		case NUMBER_OF_ORDER:
			break;
		case ORDER_FINALIZING:
			break;
	}
}

void set_payment(swipe s)
{
	switch (s) {
		case 0:
		{
			printf("Incrementing invalid payment attempts.\n");
			break;
		}
		case 1:
		{
			//printf("Resetting attempts.\n");
			break;
		}
	}
}

void getAddress()
{
	printf("Getting address\n>");
}

#endif

