#ifndef statemodel_c
#define statemodel_c

#include "statemodel.h"
#include <stdlib.h>

//Define the intitial state.
static state_t* current_state = &accepting;

void handle_event(event current_event)
{
	state_t* next_state;

	next_state = NULL;

	switch (current_event) //exit current_state and have the
							//appropiate effect.
	{
		case ORDER_RECEIVED:
			next_state = current_state->order_received();
			break;
		case PAYMENT_VALIDATED:
			next_state = current_state->payment_validated();
			break;
		case PAYMENT_REJECTED:
			next_state = current_state->payment_rejected();
			break;
		case FACTORY_FAILED:
			next_state = current_state->factory_failed();
			break;
		case FACTORY_SUCCESS:
			next_state = current_state->factory_success();
			break;
		case SHIPMENT_CONFIRMED:
			next_state = current_state->shipment_confirmed();
			break;
		case SHIPMENT_FAILED:
			next_state = current_state->shipment_failed();
			break;
		case NUMBER_OF_EVENTS:
			break;
	}

	if (next_state != NULL)
	{
		current_state = next_state;  //Change states
		current_state->entry_to();  //next_state = current_state.entry_to()
	}
}

#endif
