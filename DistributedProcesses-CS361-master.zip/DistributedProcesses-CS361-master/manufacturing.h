#ifndef manufacturing_h
#define manufacturing_h

#include "state.h"

static state_t *	factory_failed();
static state_t *	factory_success();
static void         chargeClient();
static void * 		get_in_addr();
static void			entry_to();
static void			exit_from();

#endif

