#include "statemodel.h"
#include <stdlib.h>
#include <stdio.h>

int main( void )
{
	char letter;

	printf("Current State: Accepting.\n>");

	scanf(" %c", &letter);

	while(letter != EOF)
	{
	   switch (letter)
	   {
		case ('O'):
			handle_event(ORDER_RECEIVED);
			int count = scanf("\n%c", &letter);
			break;
		case ('V'):
			handle_event(PAYMENT_VALIDATED);
			count = scanf("\n%c", &letter);
			break;
		case ('I'):
			handle_event(PAYMENT_REJECTED);
			count = scanf("\n%c", &letter);
			break;
		case ('F'):
			handle_event(FACTORY_FAILED);
			count = scanf("\n%c", &letter);
			break;
		case ('C'):
			handle_event(FACTORY_SUCCESS);
			count = scanf("\n%c", &letter);
			break;
		case ('R'):
			handle_event(SHIPMENT_CONFIRMED);
			count = scanf("\n%c", &letter);
			break;
		case ('L'):
			handle_event(SHIPMENT_FAILED);
			count = scanf("\n%c", &letter);
			break;
		case ('X'):
			printf("Goodbye, cruel world.\n");
			return 0;
		default:
			printf("You have typed an incorrect command.\n>");
			count = scanf("\n%c", &letter);
			break;
		}
	}
}
