#ifndef hardware_h
#define hardware_h

//Factory Line settings.
typedef enum
{
	LINE_ON,
	LINE_OFF,
	LINE_NUMBER_OF_SETTINGS
}	line_setting;

// Order settings
typedef enum
{
	ORDER_PROCESSING,
	ORDER_MANUFACTURING,
	ORDER_FINALIZING,
	NUMBER_OF_ORDER
}	order_setting;

//Events
typedef enum
{
	FACTORY_FAILED,
	FACTORY_SUCCESS,
	ORDER_RECEIVED,
	PAYMENT_REJECTED,
	PAYMENT_VALIDATED,
	SHIPMENT_CONFIRMED,
	SHIPMENT_FAILED,
	NUMBER_OF_EVENTS
}	event;

typedef enum
{
   DECLINED,
   ACCEPTED
}  swipe;

typedef enum
{
    CARD
}   card;

//Function for controlling the Line settings.
void factory_line(line_setting);

void get_payment_method(card);

void set_order_progress(order_setting);

void set_payment(swipe);

void getAddress();

#endif
