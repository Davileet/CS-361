#ifndef accepting_h
#define accepting_h

#include "state.h"

//Declare all of the functions in the accepting state.
static state_t* order_received();
static void entry_to();
static void exit_from();

#endif
