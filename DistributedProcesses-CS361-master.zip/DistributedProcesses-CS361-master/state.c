#ifndef state_c
#define state_c

#include <stdio.h>
#include <stdlib.h>
#include "state.h"

//Defined the default event handler and default action.

state_t * default_event_handler()
{
    printf("Invalid command. Please re-enter.\n>");
	return NULL;
}

void default_action()
{
}

#endif
