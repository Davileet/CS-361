#ifndef state_h
#define state_h

//Add an alias for a type to the global name space.
typedef struct state state_t;

//Add an alias for a type of the global name space.
typedef state_t * event_handler(void);

//Add an alias for actions.
typedef	void action(void);

//Define the format of a state struct.
struct state {
	event_handler*		order_received;
	event_handler*  	payment_validated;
	event_handler*		payment_rejected;
	event_handler*		factory_failed;
	event_handler* 		factory_success;
	event_handler*		shipment_confirmed;
	event_handler*		shipment_failed;
	action*			entry_to;
	action*			exit_from;
};

//Declare variables to hold points to the default event event_handler
//and the default action. They are extern because they are used in
//each of the individual state files but defined in state.c.
extern state_t* default_event_handler();
extern void default_action();

#endif
