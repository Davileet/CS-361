#ifndef processing_c
#define processing_c

#include <stdio.h>
#include "processing.h"
#include "hardware.h"
#include "statemodel.h" //For the other states.

//Create the object of the processing state.
state_t processing =
{
	default_event_handler,		//order receieved
	payment_validated,		//payment validated
	payment_rejected,		//payment rejected
	default_event_handler,		//factory failed
	default_event_handler,		//factory success
	default_event_handler,		//shipment confirmed
	default_event_handler,		//shipment failed
	entry_to,			//entrty
	default_action			//exit
};

state_t* payment_validated()
{
	set_payment(ACCEPTED);
	return &manufacturing;
}

state_t* payment_rejected()
{
	set_payment(DECLINED);
	return &processing;
}

void entry_to()
{
    printf("Current State: Processing.\n");
	get_payment_method(CARD);
}

#endif

