#ifndef processing_h
#define processing_h

#include "state.h"

//Declare all the functions performed when processing
static state_t*		payment_validated();
static state_t*		payment_rejected();
static void			entry_to();

#endif

